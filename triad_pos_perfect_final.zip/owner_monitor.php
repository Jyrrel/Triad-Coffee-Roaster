<?php
require __DIR__ . '/server/auth.php';
require_login();
require_role('owner');

$pdo = db();

$staffId = isset($_GET['staff_id']) ? (int)$_GET['staff_id'] : 0;
$dateFrom = trim((string)($_GET['from'] ?? ''));
$dateTo = trim((string)($_GET['to'] ?? ''));

$where = "1=1";
$params = [];

if ($staffId > 0) {
  $where .= " AND o.staff_user_id = :staff_id";
  $params[':staff_id'] = $staffId;
}
if ($dateFrom !== '') {
  $where .= " AND o.created_at >= :from";
  $params[':from'] = $dateFrom . " 00:00:00";
}
if ($dateTo !== '') {
  $where .= " AND o.created_at <= :to";
  $params[':to'] = $dateTo . " 23:59:59";
}

$staffList = $pdo->query("SELECT id, name, email FROM users WHERE role='staff' ORDER BY name ASC")->fetchAll();

$summaryStmt = $pdo->prepare("
  SELECT u.id, u.name, u.email,
         COUNT(o.id) AS orders_count,
         COALESCE(SUM(o.total),0) AS total_sales
  FROM users u
  LEFT JOIN orders o ON o.staff_user_id = u.id AND o.status='paid'
  GROUP BY u.id
  ORDER BY total_sales DESC, orders_count DESC
");
$summaryStmt->execute();
$summary = $summaryStmt->fetchAll();

$ordersStmt = $pdo->prepare("
  SELECT o.id, o.order_no, o.created_at, o.total, o.payment_method, o.status,
         u.name AS staff_name
  FROM orders o
  JOIN users u ON u.id = o.staff_user_id
  WHERE $where
  ORDER BY o.created_at DESC
  LIMIT 200
");
$ordersStmt->execute($params);
$orders = $ordersStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Owner Monitoring - Triad POS</title>
  <link rel="stylesheet" href="assets/css/styles.css" />
  <style>
    body{background:#f3f4f6;}
    .wrap{max-width:1200px;margin:20px auto;padding:0 16px;}
    .topbar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px;}
    .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 2px 10px rgba(0,0,0,.06);margin-bottom:16px;}
    table{width:100%;border-collapse:collapse;}
    th,td{padding:10px;border-bottom:1px solid #eee;text-align:left;font-size:14px;}
    th{background:#fafafa;font-weight:600;}
    .pill{display:inline-block;padding:4px 10px;border-radius:999px;background:#eef2ff;font-size:12px;}
    .muted{opacity:.7}
    .row{display:flex;gap:12px;flex-wrap:wrap}
    .row > *{flex:1}
    .btn{display:inline-block;padding:10px 14px;border-radius:10px;background:#1e3a8a;color:#fff;text-decoration:none;border:none;cursor:pointer}
    .btn.light{background:#111827}
    input,select{width:100%;padding:10px;border:1px solid #ddd;border-radius:10px}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="topbar">
      <div>
        <h2 style="margin:0;">Owner Monitoring</h2>
        <div class="muted">View staff sales and orders</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a class="btn light" href="owner.php">Back to Dashboard</a>
        <a class="btn" href="owner_staff.php">Manage Staff</a>
      </div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Sales per Staff</h3>
      <table>
        <thead>
          <tr>
            <th>Staff</th>
            <th>Email</th>
            <th>Orders</th>
            <th>Total Sales</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($summary as $s): ?>
            <tr>
              <td><?= htmlspecialchars($s['name']) ?></td>
              <td class="muted"><?= htmlspecialchars($s['email']) ?></td>
              <td><?= (int)$s['orders_count'] ?></td>
              <td>₱<?= number_format((float)$s['total_sales'], 2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Filter Orders</h3>
      <form method="get" class="row">
        <div>
          <label class="muted">Staff</label>
          <select name="staff_id">
            <option value="0">All staff</option>
            <?php foreach($staffList as $st): ?>
              <option value="<?= (int)$st['id'] ?>" <?= $staffId===(int)$st['id']?'selected':'' ?>>
                <?= htmlspecialchars($st['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="muted">From</label>
          <input type="date" name="from" value="<?= htmlspecialchars($dateFrom) ?>" />
        </div>
        <div>
          <label class="muted">To</label>
          <input type="date" name="to" value="<?= htmlspecialchars($dateTo) ?>" />
        </div>
        <div style="align-self:flex-end;">
          <button class="btn" type="submit">Apply</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">Recent Orders</h3>
      <table>
        <thead>
          <tr>
            <th>Order #</th>
            <th>Staff</th>
            <th>Date</th>
            <th>Payment</th>
            <th>Total</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php if(!$orders): ?>
            <tr><td colspan="7" class="muted">No orders found.</td></tr>
          <?php endif; ?>
          <?php foreach($orders as $o): ?>
            <tr>
              <td><span class="pill"><?= htmlspecialchars($o['order_no']) ?></span></td>
              <td><?= htmlspecialchars($o['staff_name']) ?></td>
              <td class="muted"><?= htmlspecialchars($o['created_at']) ?></td>
              <td><?= htmlspecialchars(strtoupper($o['payment_method'])) ?></td>
              <td>₱<?= number_format((float)$o['total'],2) ?></td>
              <td><?= htmlspecialchars($o['status']) ?></td>
              <td><a href="owner_order.php?id=<?= (int)$o['id'] ?>">View</a></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </div>
</body>
</html>
