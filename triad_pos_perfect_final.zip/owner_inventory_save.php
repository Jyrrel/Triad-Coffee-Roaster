<?php
require __DIR__ . '/server/auth.php';
require_login();
require_role('owner');

$pdo = db();

$action = $_POST['action'] ?? '';
$id = (int)($_POST['id'] ?? 0);

try {
  if ($action === 'update' && $id > 0) {
    $stock = (int)($_POST['stock'] ?? 0);
    $thr = (int)($_POST['thr'] ?? 10);
    if ($thr < 0) $thr = 0;

    // read current stock for log
    $cur = $pdo->prepare("SELECT stock FROM products WHERE id=:id");
    $cur->execute([':id'=>$id]);
    $row = $cur->fetch();
    if (!$row) throw new Exception("Product not found.");

    $oldStock = (int)$row['stock'];
    $delta = $stock - $oldStock;

    $stmt = $pdo->prepare("UPDATE products SET stock=:stock, low_stock_threshold=:thr WHERE id=:id");
    $stmt->execute([':stock'=>$stock, ':thr'=>$thr, ':id'=>$id]);

    if ($delta !== 0) {
      $log = $pdo->prepare("INSERT INTO inventory_logs (product_id, user_id, change_qty, reason, meta) VALUES (:pid,:uid,:chg,'adjust',:meta)");
      $log->execute([
        ':pid'=>$id,
        ':uid'=>(int)$_SESSION['user']['id'],
        ':chg'=>$delta,
        ':meta'=>json_encode(['from'=>$oldStock,'to'=>$stock], JSON_UNESCAPED_SLASHES),
      ]);
    }
  }

  if ($action === 'toggle' && $id > 0) {
    $stmt = $pdo->prepare("UPDATE products SET is_active = IF(is_active=1,0,1) WHERE id=:id");
    $stmt->execute([':id'=>$id]);

    $log = $pdo->prepare("INSERT INTO inventory_logs (product_id, user_id, change_qty, reason, meta) VALUES (:pid,:uid,0,'toggle',:meta)");
    $log->execute([
      ':pid'=>$id,
      ':uid'=>(int)$_SESSION['user']['id'],
      ':meta'=>json_encode(['toggled'=>true], JSON_UNESCAPED_SLASHES),
    ]);
  }

} catch (Throwable $e) {
  // optional: show error on redirect
  header('Location: /triad-pos/owner.php#inventory&err=' . urlencode($e->getMessage()));
  exit;
}

header('Location: /triad-pos/owner.php#inventory');
exit;
?>