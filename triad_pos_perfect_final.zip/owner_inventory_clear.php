<?php
require __DIR__ . '/server/auth.php';
require_login();
require_role('owner');
$pdo = db();
$pdo->exec("TRUNCATE TABLE inventory_logs");
header('Location: /triad-pos/owner.php#lowstock');
exit;
?>