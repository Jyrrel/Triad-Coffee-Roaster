<?php
// ===== DATABASE CONFIG =====
// Update these to match your phpMyAdmin / MySQL setup
define('DB_HOST', 'localhost');
define('DB_NAME', 'triad_pos');
define('DB_USER', 'root');
define('DB_PASS', '');

// Session settings
define('SESSION_NAME', 'triad_session');
?>