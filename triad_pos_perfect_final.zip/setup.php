<?php
// Run once after importing schema.sql (then delete this file for security)
require_once __DIR__ . '/server/db.php';
require_once __DIR__ . '/server/config.php';

try {
  $pdo = db();

  $accounts = [
    ['Triad Owner', 'owner@triad.local', 'Owner123!', 'owner'],
    ['Triad Staff', 'staff@triad.local', 'Staff123!', 'staff'],
  ];

  foreach ($accounts as [$name,$email,$pass,$role]) {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare('INSERT INTO users (name,email,password_hash,role,is_active) VALUES (?,?,?,?,1)
      ON DUPLICATE KEY UPDATE name=VALUES(name), password_hash=VALUES(password_hash), role=VALUES(role), is_active=1');
    $stmt->execute([$name, $email, $hash, $role]);
  }


  // Seed products for inventory + low-stock demo
  $products = [
    ['Caramel Latte','hot-coffee',3.95,50,10],
    ['Americano','hot-coffee',3.10,50,10],
    ['Cappuccino','hot-coffee',3.50,6,10],
    ['Mocha Frappe','hot-coffee',4.25,6,10],
    ['Matcha Latte','hot-coffee',3.85,50,10],
    ['Golden Turmeric Latte','hot-coffee',2.40,50,10],
    ['House Blend Beans (250g)','hot-coffee',8.99,6,10],
    ['Iced Latte','iced-coffee',3.80,50,10],
    ['Vanilla Cold Brew','iced-coffee',3.95,50,10],
    ['Single Espresso','espresso',2.20,50,10],
    ['Double Espresso','espresso',2.95,50,10],
    ['Mocha Frappe','frappe',4.25,6,10],
    ['Caramel Frappe','frappe',4.35,50,10],
    ['Matcha Latte','tea',3.85,50,10],
    ['Classic Black Tea','tea',2.50,50,10],
    ['Butter Croissant','pastries',2.40,6,10],
    ['Chocolate Muffin','pastries',2.80,50,10],
    ['Darkfruit Blend','beans',8.99,50,10],
    ['Mono Blend','beans',9.50,6,10],
    ['Espresso Beans','beans',10.99,0,10],
  ];

  $pstmt = $pdo->prepare("INSERT INTO products (name, category, price, stock, low_stock_threshold, is_active)
    VALUES (:name,:category,:price,:stock,:thr,1)
    ON DUPLICATE KEY UPDATE category=VALUES(category), price=VALUES(price), stock=VALUES(stock), low_stock_threshold=VALUES(low_stock_threshold), is_active=1");
  foreach ($products as $p) {
    $pstmt->execute([
      ':name' => $p[0],
      ':category' => $p[1],
      ':price' => $p[2],
      ':stock' => (int)$p[3],
      ':thr' => (int)$p[4],
    ]);
  }

  echo "✅ Sample accounts created/updated.\n";
  echo "Owner: owner@triad.local / Owner123!\n";
  echo "Staff: staff@triad.local / Staff123!\n";
  echo "\nIMPORTANT: Delete setup.php after running.\n";
} catch (Throwable $e) {
  http_response_code(500);
  echo "❌ Error: " . $e->getMessage();
}
?>