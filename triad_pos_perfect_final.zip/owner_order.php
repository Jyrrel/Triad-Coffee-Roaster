<?php
require __DIR__ . '/server/auth.php';
require_login();
require_role('owner');

$pdo = db();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) { header('Location: owner_monitor.php'); exit; }

$order = $pdo->prepare("
  SELECT o.*, u.name AS staff_name, u.email AS staff_email
  FROM orders o
  JOIN users u ON u.id = o.staff_user_id
  WHERE o.id = :id
");
$order->execute([':id'=>$id]);
$o = $order->fetch();
if (!$o) { header('Location: owner_monitor.php'); exit; }

$itemsStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = :id");
$itemsStmt->execute([':id'=>$id]);
$items = $itemsStmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Order <?= htmlspecialchars($o['order_no']) ?> - Owner</title>
  <style>
    body{font-family:Arial,Helvetica,sans-serif;background:#f3f4f6;margin:0}
    .wrap{max-width:900px;margin:20px auto;padding:0 16px}
    .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 2px 10px rgba(0,0,0,.06)}
    table{width:100%;border-collapse:collapse;margin-top:10px}
    th,td{padding:10px;border-bottom:1px solid #eee;text-align:left;font-size:14px}
    th{background:#fafafa}
    .btn{display:inline-block;padding:10px 14px;border-radius:10px;background:#111827;color:#fff;text-decoration:none}
    .pill{display:inline-block;padding:4px 10px;border-radius:999px;background:#eef2ff;font-size:12px;}
    .muted{opacity:.7}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
    @media(max-width:700px){.grid{grid-template-columns:1fr}}
  </style>
</head>
<body>
  <div class="wrap">
    <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
      <div>
        <h2 style="margin:0;">Order <span class="pill"><?= htmlspecialchars($o['order_no']) ?></span></h2>
        <div class="muted"><?= htmlspecialchars($o['created_at']) ?></div>
      </div>
      <a class="btn" href="owner_monitor.php">Back</a>
    </div>

    <div class="card" style="margin-top:14px;">
      <div class="grid">
        <div>
          <h3 style="margin:0 0 6px;">Staff</h3>
          <div><?= htmlspecialchars($o['staff_name']) ?> <span class="muted">(<?= htmlspecialchars($o['staff_email']) ?>)</span></div>
        </div>
        <div>
          <h3 style="margin:0 0 6px;">Payment</h3>
          <div><?= htmlspecialchars(strtoupper($o['payment_method'])) ?> • Status: <?= htmlspecialchars($o['status']) ?></div>
        </div>
        <div>
          <h3 style="margin:0 0 6px;">Customer</h3>
          <div><?= htmlspecialchars($o['customer_name'] ?: '-') ?></div>
          <div class="muted">Persons: <?= (int)$o['persons'] ?></div>
        </div>
        <div>
          <h3 style="margin:0 0 6px;">Totals</h3>
          <div>Subtotal: ₱<?= number_format((float)$o['subtotal'],2) ?></div>
          <div>VAT: ₱<?= number_format((float)$o['vat'],2) ?></div>
          <div>Discount: ₱<?= number_format((float)$o['discount'],2) ?></div>
          <div><b>Total: ₱<?= number_format((float)$o['total'],2) ?></b></div>
          <div class="muted">Paid: ₱<?= number_format((float)$o['amount_paid'],2) ?> • Change: ₱<?= number_format((float)$o['change_due'],2) ?></div>
        </div>
      </div>

      <h3 style="margin-top:16px;">Items</h3>
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Price</th>
            <th>Qty</th>
            <th>Line Total</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($items as $it): ?>
            <tr>
              <td><?= htmlspecialchars($it['item_name']) ?></td>
              <td>₱<?= number_format((float)$it['item_price'],2) ?></td>
              <td><?= (int)$it['qty'] ?></td>
              <td>₱<?= number_format((float)$it['line_total'],2) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
