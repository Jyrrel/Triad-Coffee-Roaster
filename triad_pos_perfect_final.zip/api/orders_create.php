<?php
require_once __DIR__ . '/../server/auth.php';
require_login();
require_role('staff');

header('Content-Type: application/json; charset=utf-8');

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

$items = $data['items'] ?? [];
$summary = $data['summary'] ?? [];

if (!is_array($items) || count($items) === 0) {
  echo json_encode(['ok'=>false,'message'=>'Cart is empty.']);
  exit;
}

function num($v): float {
  return is_numeric($v) ? (float)$v : 0.0;
}

$customer = trim((string)($summary['customer_name'] ?? ''));
$persons = (int)($summary['persons'] ?? 1);
if ($persons < 1) $persons = 1;

$pay = strtolower(trim((string)($summary['payment_method'] ?? 'cash')));
if (!in_array($pay, ['cash','gcash','card'], true)) $pay = 'cash';

$subtotal = num($summary['subtotal'] ?? 0);
$discount = num($summary['discount'] ?? 0);
$vat = num($summary['vat'] ?? 0);
$total = num($summary['total'] ?? 0);
$paid = num($summary['amount_paid'] ?? 0);
$change = num($summary['change_due'] ?? 0);

$pdo = db();
$pdo->beginTransaction();

try {
  $orderNo = 'TRIAD-' . date('Ymd-His') . '-' . random_int(1000, 9999);

  $stmt = $pdo->prepare("
    INSERT INTO orders
      (order_no, staff_user_id, customer_name, persons, payment_method, subtotal, discount, vat, total, amount_paid, change_due)
    VALUES
      (:order_no, :staff_id, :customer, :persons, :payment, :subtotal, :discount, :vat, :total, :paid, :change_due)
  ");
  $stmt->execute([
    ':order_no' => $orderNo,
    ':staff_id' => (int)$_SESSION['user']['id'],
    ':customer' => $customer ?: null,
    ':persons' => $persons,
    ':payment' => $pay,
    ':subtotal' => $subtotal,
    ':discount' => $discount,
    ':vat' => $vat,
    ':total' => $total,
    ':paid' => $paid,
    ':change_due' => $change,
  ]);

  $orderId = (int)$pdo->lastInsertId();

  
  $itemStmt = $pdo->prepare("
    INSERT INTO order_items (order_id, item_name, item_price, qty, line_total)
    VALUES (:order_id, :name, :price, :qty, :line_total)
  ");

  $prodSel = $pdo->prepare("SELECT id, stock, is_active FROM products WHERE name = :name LIMIT 1 FOR UPDATE");
  $prodUpd = $pdo->prepare("UPDATE products SET stock = stock - :qty WHERE id = :pid");
  $invLog = $pdo->prepare("INSERT INTO inventory_logs (product_id, user_id, change_qty, reason, meta) VALUES (:pid, :uid, :chg, :reason, :meta)");

  foreach ($items as $it) {
    $name = trim((string)($it['name'] ?? 'Item'));
    $price = num($it['price'] ?? 0);
    $qty = (int)($it['qty'] ?? 1);
    if ($qty < 1) $qty = 1;
    $line = $price * $qty;

    // Save order line
    $itemStmt->execute([
      ':order_id' => $orderId,
      ':name' => $name,
      ':price' => $price,
      ':qty' => $qty,
      ':line_total' => $line,
    ]);

    // Deduct inventory (if product exists). Prevent negative stock.
    $prodSel->execute([':name' => $name]);
    $prod = $prodSel->fetch();
    if ($prod) {
      if (!(int)$prod['is_active']) {
        throw new Exception("Product is disabled: " . $name);
      }
      $current = (int)$prod['stock'];
      if ($current < $qty) {
        throw new Exception("Not enough stock for " . $name . ". Available: " . $current);
      }
      $prodUpd->execute([':qty' => $qty, ':pid' => (int)$prod['id']]);

      $invLog->execute([
        ':pid' => (int)$prod['id'],
        ':uid' => (int)$_SESSION['user']['id'],
        ':chg' => -1 * $qty,
        ':reason' => 'sale',
        ':meta' => json_encode(['order_no'=>$orderNo], JSON_UNESCAPED_SLASHES),
      ]);
    }
  }


    $logStmt = $pdo->prepare("INSERT INTO staff_logs (user_id, action, meta) VALUES (:uid, :action, :meta)");
  $logStmt->execute([
    ':uid' => (int)$_SESSION['user']['id'],
    ':action' => 'order_created',
    ':meta' => json_encode(['order_no'=>$orderNo, 'total'=>$total], JSON_UNESCAPED_SLASHES),
  ]);

  $pdo->commit();

  echo json_encode(['ok'=>true, 'order_no'=>$orderNo, 'order_id'=>$orderId]);
  exit;
} catch (Throwable $e) {
  $pdo->rollBack();
  echo json_encode(['ok'=>false,'message'=>'Failed to save order.','error'=>$e->getMessage()]);
  exit;
}
?>