document.addEventListener("DOMContentLoaded", () => {
  // =========================
  // SETTINGS
  // =========================
  const TAX_RATE = 0.10;
  const DISCOUNT_RATE = 0.10;

  // Mark best sellers by item ID (edit this list any time)
  const BEST_SELLER_IDS = new Set([1, 2, 3, 4, 8, 9, 13, 15, 17, 21]);

  // =========================
  // DOM HELPERS
  // =========================
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  const menuGrid = document.querySelector("[data-menu-grid]");
  const searchInput = document.querySelector("[data-search-input]");
  const cartEl = document.querySelector("[data-cart]");
  const subtotalEl = document.querySelector("[data-subtotal]");
  const taxEl = document.querySelector("[data-tax]");
  const discountEl = document.querySelector("[data-discount]");
  const totalEl = document.querySelector("[data-total]");

  const catButtons = $$(".cat");
  const payButtons = $$(".pay-btn");

  const personCountEl = document.querySelector("[data-person-count]");
  const tableTextEl = document.querySelector("[data-table-text]");
  const decPersonBtn = document.querySelector('[data-action="decrease-person"]');
  const incPersonBtn = document.querySelector('[data-action="increase-person"]');

  // =========================
  // 1) HERO SLIDER (every 5 seconds)
  // =========================
  (function heroSlider() {
    const slides = $$(".hero-slider .slide");
    if (!slides.length) return;

    let idx = slides.findIndex(s => s.classList.contains("active"));
    if (idx < 0) idx = 0;

    const show = (i) => {
      slides.forEach(s => s.classList.remove("active"));
      slides[i].classList.add("active");
    };

    show(idx);
    setInterval(() => {
      idx = (idx + 1) % slides.length;
      show(idx);
    }, 5000);
  })();

  // =========================
  // 2) BEST SELLER BADGE
  // =========================
  (function markBestSellers() {
    const cards = $$("[data-item]");
    cards.forEach(card => {
      const id = Number(card.dataset.id);
      if (BEST_SELLER_IDS.has(id)) card.classList.add("bestseller");
    });
  })();

  // =========================
  // 3) CATEGORY FILTER
  // =========================
  let activeCategory = "hot-coffee";

  function applyFilters() {
    const q = (searchInput?.value || "").trim().toLowerCase();
    const cards = $$("[data-item]");

    cards.forEach(card => {
      const name = (card.dataset.name || "").toLowerCase();
      const cat = card.dataset.category || "";

      const matchesCategory = activeCategory === "all"
        ? true
        : cat === activeCategory;

      const matchesSearch = q === "" ? true : name.includes(q);

      card.style.display = (matchesCategory && matchesSearch) ? "" : "none";
    });
  }

  catButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      catButtons.forEach(b => {
        b.classList.remove("active");
        b.setAttribute("aria-selected", "false");
      });
      btn.classList.add("active");
      btn.setAttribute("aria-selected", "true");

      activeCategory = btn.dataset.category;
      applyFilters();
    });
  });

  searchInput?.addEventListener("input", applyFilters);

  // run once
  applyFilters();

  // =========================
  // 4) CART SYSTEM (Add / Remove / Qty / Totals)
  // =========================
  const cart = new Map(); // id -> {id,name,price,img,qty}

  function money(n) {
    return `$${n.toFixed(2)}`;
  }

  function calcTotals() {
    let subtotal = 0;
    cart.forEach(item => subtotal += item.price * item.qty);

    const tax = subtotal * TAX_RATE;
    const discount = subtotal * DISCOUNT_RATE;
    const total = subtotal + tax - discount;

    if (subtotalEl) subtotalEl.textContent = money(subtotal);
    if (taxEl) taxEl.textContent = money(tax);
    if (discountEl) discountEl.textContent = `-${money(discount)}`;
    if (totalEl) totalEl.textContent = money(total);
  }

  function renderCart() {
    if (!cartEl) return;

    cartEl.innerHTML = "";

    if (cart.size === 0) {
      cartEl.innerHTML = `<div class="mini-link" style="text-align:center; padding:10px;">Cart is empty</div>`;
      calcTotals();
      return;
    }

    cart.forEach(item => {
      const row = document.createElement("div");
      row.className = "order-item";
      row.setAttribute("data-cart-item", "");
      row.setAttribute("data-id", item.id);

      row.innerHTML = `
        <img src="${item.img}" alt="${item.name}">
        <div class="order-info">
          <div class="order-name">${item.name}</div>
          <div class="order-price">${money(item.price)}</div>
        </div>
        <div class="order-actions">
          <button class="round" type="button" data-action="decrease-item" aria-label="Decrease">−</button>
          <span class="badge" data-qty>${item.qty}</span>
          <button class="round" type="button" data-action="increase-item" aria-label="Increase">+</button>
          <button class="mini-link" type="button" data-action="remove-item">Remove</button>
        </div>
      `;

      cartEl.appendChild(row);
    });

    calcTotals();
  }

  function addToCartFromCard(card) {
    const id = card.dataset.id;
    const name = card.dataset.name;
    const price = Number(card.dataset.price || 0);
    const img = $("img", card)?.getAttribute("src") || "";

    if (!id || !name || !price) return;

    const existing = cart.get(id);
    if (existing) {
      existing.qty += 1;
    } else {
      cart.set(id, { id, name, price, img, qty: 1 });
    }

    renderCart();
  }

  // Add button click (event delegation)
  menuGrid?.addEventListener("click", (e) => {
    const btn = e.target.closest('[data-action="add-to-cart"], .pill');
    if (!btn) return;

    const card = e.target.closest("[data-item]");
    if (!card) return;

    addToCartFromCard(card);
  });

  // Cart actions: + / - / remove
  cartEl?.addEventListener("click", (e) => {
    const row = e.target.closest("[data-cart-item]");
    if (!row) return;

    const id = row.dataset.id;
    const item = cart.get(id);
    if (!item) return;

    const actionBtn = e.target.closest("button");
    if (!actionBtn) return;

    const action = actionBtn.dataset.action;

    if (action === "increase-item") {
      item.qty += 1;
    } else if (action === "decrease-item") {
      item.qty -= 1;
      if (item.qty <= 0) cart.delete(id);
    } else if (action === "remove-item") {
      cart.delete(id);
    }

    renderCart();
  });

  
  // =========================
  // 4.5) CONTINUE TO PAYMENT (SAVE ORDER TO DATABASE)
  // =========================
  const continuePaymentBtn = document.querySelector('[data-action="continue-payment"]');

  function getActivePayment() {
    const active = payButtons.find(b => b.classList.contains("active"));
    const p = (active?.dataset?.payment || "cash").toLowerCase();
    if (p === "ewallet") return "gcash";
    return p;
  }

  function computeTotals() {
    let subtotal = 0;
    cart.forEach(item => subtotal += item.price * item.qty);
    const vat = subtotal * TAX_RATE;
    const discount = subtotal * DISCOUNT_RATE;
    const total = subtotal + vat - discount;
    return { subtotal, vat, discount, total };
  }

  async function saveOrderToDb() {
    const totals = computeTotals();
    const persons = personCountEl ? parseInt(personCountEl.textContent || "1", 10) : 1;
    const payment_method = getActivePayment();

    let amount_paid = totals.total;
    let change_due = 0;

    if (payment_method === "cash") {
      const input = prompt("Enter cash amount paid (₱):", String(Math.ceil(totals.total)));
      if (input === null) return null; // cancelled
      const paid = parseFloat(input);
      if (!isFinite(paid) || paid < totals.total) {
        alert("Invalid cash amount. Must be at least the total.");
        return null;
      }
      amount_paid = paid;
      change_due = paid - totals.total;
    }

    const customer_name = ""; // optional: you can add an input in UI later

    const payload = {
      items: Array.from(cart.values()).map(it => ({ name: it.name, price: it.price, qty: it.qty })),
      summary: {
        customer_name,
        persons,
        payment_method,
        subtotal: totals.subtotal,
        vat: totals.vat,
        discount: totals.discount,
        total: totals.total,
        amount_paid,
        change_due
      }
    };

    const res = await fetch("/triad-pos/api/orders_create.php", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json().catch(() => ({}));
    if (!data.ok) {
      alert(data.message || "Failed to save order.");
      return null;
    }
    return { order_no: data.order_no, totals, amount_paid, change_due, payment_method, persons };
  }

  function printReceipt(orderInfo) {
    const now = new Date();
    const lines = Array.from(cart.values()).map(it => `
      <tr>
        <td>${escapeHtml(it.name)}</td>
        <td style="text-align:right;">${money(it.price)}</td>
        <td style="text-align:right;">${it.qty}</td>
        <td style="text-align:right;">${money(it.price * it.qty)}</td>
      </tr>
    `).join("");

    const html = `
    <html>
      <head>
        <title>Receipt ${orderInfo.order_no}</title>
        <meta charset="utf-8" />
        <style>
          body{font-family:Arial,Helvetica,sans-serif;padding:20px;}
          h2{margin:0 0 6px;}
          .muted{opacity:.7;font-size:12px;}
          table{width:100%;border-collapse:collapse;margin-top:12px;}
          th,td{padding:8px;border-bottom:1px solid #eee;font-size:12px;}
          th{text-align:left;background:#fafafa;}
          .totals{margin-top:10px;font-size:12px;}
          .totals div{display:flex;justify-content:space-between;margin:2px 0;}
        </style>
      </head>
      <body>
        <h2>TRIAD Coffee Roasters</h2>
        <div class="muted">${now.toLocaleString()}</div>
        <div class="muted">Order: <b>${orderInfo.order_no}</b></div>
        <div class="muted">Payment: <b>${orderInfo.payment_method.toUpperCase()}</b> • Persons: <b>${orderInfo.persons}</b></div>

        <table>
          <thead>
            <tr><th>Item</th><th style="text-align:right;">Price</th><th style="text-align:right;">Qty</th><th style="text-align:right;">Total</th></tr>
          </thead>
          <tbody>${lines}</tbody>
        </table>

        <div class="totals">
          <div><span>Subtotal</span><span>${money(orderInfo.totals.subtotal)}</span></div>
          <div><span>VAT</span><span>${money(orderInfo.totals.vat)}</span></div>
          <div><span>Discount</span><span>-${money(orderInfo.totals.discount)}</span></div>
          <div><b>Total</b><b>${money(orderInfo.totals.total)}</b></div>
          <div><span>Paid</span><span>${money(orderInfo.amount_paid)}</span></div>
          <div><span>Change</span><span>${money(orderInfo.change_due)}</span></div>
        </div>

        <p class="muted">Thank you!</p>
        <script>window.print();</script>
      </body>
    </html>`;
    const w = window.open("", "_blank", "width=480,height=700");
    w.document.open();
    w.document.write(html);
    w.document.close();
  }

  function escapeHtml(str){
    return String(str)
      .replaceAll("&","&amp;")
      .replaceAll("<","&lt;")
      .replaceAll(">","&gt;")
      .replaceAll('"',"&quot;")
      .replaceAll("'","&#039;");
  }

  if (continuePaymentBtn) {
    continuePaymentBtn.addEventListener("click", async () => {
      if (cart.size === 0) {
        alert("Cart is empty.");
        return;
      }
      const info = await saveOrderToDb();
      if (!info) return;

      // Print receipt
      printReceipt(info);

      // Clear cart after successful save
      cart.clear();
      renderCart();
      alert("Order saved! Order No: " + info.order_no);
    });
  }

// first render
  renderCart();

  // =========================
  // 5) PAYMENT METHOD ACTIVE TOGGLE
  // =========================
  payButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      payButtons.forEach(b => {
        b.classList.remove("active");
        b.setAttribute("aria-checked", "false");
      });
      btn.classList.add("active");
      btn.setAttribute("aria-checked", "true");
    });
  });

  // =========================
  // 6) PERSON COUNT +/- FUNCTION
  // =========================
  function setPersonCount(newCount) {
    const count = Math.max(1, newCount);
    if (personCountEl) personCountEl.textContent = String(count);
    if (tableTextEl) tableTextEl.value = `${count} Person Table`;
  }

  decPersonBtn?.addEventListener("click", () => {
    const current = Number(personCountEl?.textContent || 1);
    setPersonCount(current - 1);
  });

  incPersonBtn?.addEventListener("click", () => {
    const current = Number(personCountEl?.textContent || 1);
    setPersonCount(current + 1);
  });
});
